import { randomBytes, randomUUID, createHash, scrypt as scryptCb, timingSafeEqual } from 'node:crypto'
import { promisify } from 'node:util'
import sharp from 'sharp'
const scrypt = promisify(scryptCb),
  hash = (s) => createHash('sha256').update(s).digest('hex'),
  prefix = 'atlas-deva:v2:'
const categories = [
  'Istorie',
  'Cultură',
  'Natură',
  'Arhitectură',
  'Transport',
  'Magazine',
  'Gastronomie',
  'Cazare',
  'Servicii',
  'Instituții',
]
const kinds = ['Groapă', 'Iluminat defect', 'Spațiu verde', 'Propunere', 'Loc interesant', 'Observație']
const sections = ['location', 'event'],
  ttl = 7200
let db
function fail(code, message) {
  throw Object.assign(new Error(message), { code })
}
function text(v, min, max) {
  if (typeof v !== 'string' || v.trim().length < min || v.length > max)
    fail(400, 'Un câmp este lipsă sau depășește limita permisă.')
  return v.trim()
}
function url(v, optional = false) {
  if (!v && optional) return ''
  const s = text(v, 6, 1000)
  try {
    const u = new URL(s)
    if (u.protocol !== 'https:' || u.username || u.password) throw Error()
    return u.href
  } catch {
    fail(400, 'Folosește o adresă web HTTPS validă.')
  }
}
function slug(v) {
  if (typeof v !== 'string' || !/^[a-z0-9][a-z0-9-]{0,89}$/.test(v)) fail(400, 'Identificator invalid.')
  return v
}
function local() {
  return !process.env.VERCEL && !!process.env.ATLAS_SQLITE_PATH
}
function ready() {
  return local() || !!(process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN)
}
function adminReady() {
  return (
    ready() &&
    !!process.env.ATLAS_ADMIN_USER &&
    /^([a-f0-9]{32}):([a-f0-9]{128})$/.test(process.env.ATLAS_ADMIN_HASH || '')
  )
}
async function cmd(...args) {
  if (local()) {
    if (!db) {
      const { DatabaseSync } = await import('node:sqlite')
      db = new DatabaseSync(process.env.ATLAS_SQLITE_PATH)
      db.exec(
        'PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT NOT NULL,t INTEGER DEFAULT 0); CREATE TABLE IF NOT EXISTS docs(k TEXT,id TEXT,v TEXT, PRIMARY KEY(k,id));',
      )
    }
    const [op, k, x, v] = args
    db.prepare('DELETE FROM kv WHERE t>0 AND t<?').run(Date.now())
    if (op === 'GET') return db.prepare('SELECT v FROM kv WHERE k=?').get(k)?.v ?? null
    if (op === 'SET') {
      db.prepare('INSERT OR REPLACE INTO kv VALUES(?,?,?)').run(
        k,
        String(x),
        args[3] === 'EX' ? Date.now() + Number(args[4]) * 1000 : 0,
      )
      return 'OK'
    }
    if (op === 'DEL') {
      db.prepare('DELETE FROM kv WHERE k=?').run(k)
      return 1
    }
    if (op === 'HSET') {
      db.prepare('INSERT OR REPLACE INTO docs VALUES(?,?,?)').run(k, x, v)
      return 1
    }
    if (op === 'HDEL') {
      db.prepare('DELETE FROM docs WHERE k=? AND id=?').run(k, x)
      return 1
    }
    if (op === 'HVALS')
      return db
        .prepare('SELECT v FROM docs WHERE k=? LIMIT 2500')
        .all(k)
        .map((r) => r.v)
    if (op === 'HGET') return db.prepare('SELECT v FROM docs WHERE k=? AND id=?').get(k, x)?.v ?? null
    if (op === 'EVAL') {
      const key = args[3],
        seconds = args[4]
      db.prepare('INSERT INTO kv VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=CAST(v AS INTEGER)+1').run(
        key,
        '1',
        Date.now() + seconds * 1000,
      )
      return Number(db.prepare('SELECT v FROM kv WHERE k=?').get(key).v)
    }
    throw Error('Unknown storage command')
  }
  const r = await fetch(process.env.UPSTASH_REDIS_REST_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.UPSTASH_REDIS_REST_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(args),
    signal: AbortSignal.timeout(7000),
  })
  if (!r.ok) throw Error('Storage unavailable')
  const v = await r.json()
  if (v.error) throw Error('Storage unavailable')
  return v.result
}
const list = async (k) => (await cmd('HVALS', prefix + k)).map((v) => JSON.parse(v))
const write = (k, id, v) => cmd('HSET', prefix + k, id, JSON.stringify(v)),
  get = async (k, id) => JSON.parse((await cmd('HGET', prefix + k, id)) || 'null')
async function limit(req, name, max, seconds) {
  const ip = process.env.VERCEL
    ? req.headers['x-vercel-forwarded-for'] || req.socket?.remoteAddress || 'unknown'
    : req.socket?.remoteAddress || 'local'
  const key = prefix + 'limit:' + name + ':' + hash(String(ip)).slice(0, 32)
  const n = await cmd(
    'EVAL',
    "local n=redis.call('INCR',KEYS[1]);if n==1 then redis.call('EXPIRE',KEYS[1],ARGV[1]);end;return n",
    1,
    key,
    seconds,
  )
  if (n > max) fail(429, 'Prea multe încercări. Reîncearcă mai târziu.')
}
async function photo(input, privateUpload = false) {
  if (!input) return ''
  if (
    typeof input !== 'string' ||
    input.length > 2900000 ||
    !/^data:image\/(jpeg|png|webp);base64,/.test(input)
  )
    fail(400, 'Imagine invalidă. Sunt acceptate fotografii JPEG, PNG sau WebP.')
  try {
    const b = Buffer.from(input.split(',')[1], 'base64')
    const image = sharp(b, { limitInputPixels: 16000000, failOn: 'error' })
    const meta = await image.metadata()
    if (!['jpeg', 'png', 'webp'].includes(meta.format) || meta.pages > 1) throw Error()
    const processed = await image
      .rotate()
      .resize({ width: 1400, height: 1400, fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 80 })
      .toBuffer()
    if (processed.length > 900000) throw Error()
    const id = randomUUID()
    await write(privateUpload ? 'private-media' : 'media', id, { data: processed.toString('base64') })
    return '/api/atlas?action=image&id=' + id
  } catch {
    fail(400, 'Fotografia nu a putut fi validată. Alege o imagine mai mică.')
  }
}
function imageRef(s) {
  if (!s) return '/map/small-atlas.webp'
  if (
    typeof s !== 'string' ||
    (!/^\/(?:images|map)\/[a-z0-9/-]+\.webp$/.test(s) &&
      !/^\/api\/atlas\?action=image&id=[a-f0-9-]{36}$/.test(s))
  )
    fail(400, 'Imagine nevalidată.')
  return s
}
function sessionId(req) {
  return (req.headers.cookie || '').match(/(?:^|;\s*)__Host-atlas_admin=([a-f0-9]{64})(?:;|$)/)?.[1] || ''
}
async function auth(req) {
  if (!adminReady()) fail(503, 'Administrarea necesită configurarea contului și a stocării pe server.')
  const id = sessionId(req)
  const record = id && (await cmd('GET', prefix + 'session:' + hash(id)))
  if (!record) fail(401, 'Autentificare necesară.')
  const s = JSON.parse(record)
  if (s.role !== 'administrator' || s.user !== process.env.ATLAS_ADMIN_USER) fail(403, 'Acces neautorizat.')
  if (req.method !== 'GET' && req.headers['x-atlas-csrf'] !== s.csrf) fail(403, 'Sesiunea trebuie reînnoită.')
  return s
}
function send(res, code, data) {
  res.statusCode = code
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.end(JSON.stringify(data))
}
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store')
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('Vary', 'Cookie')
  try {
    const target = new URL(req.url, 'https://atlas.local'),
      action = target.searchParams.get('action') || 'public'
    if (!['GET', 'POST'].includes(req.method)) fail(405, 'Metodă neacceptată.')
    if (req.method === 'POST') {
      const origin = req.headers.origin
      const expected = process.env.ATLAS_ORIGIN
      if (!origin || (expected ? origin !== expected : new URL(origin).host !== req.headers.host))
        fail(403, 'Origine neacceptată.')
      if (!String(req.headers['content-type'] || '').startsWith('application/json'))
        fail(415, 'Se acceptă numai JSON.')
      if (Number(req.headers['content-length'] || 0) > 3200000) fail(413, 'Fișier prea mare.')
    }
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {}
    if (req.method === 'POST' && Buffer.byteLength(JSON.stringify(body)) > 3200000)
      fail(413, 'Fișier prea mare.')
    if (action === 'public' && req.method === 'GET') {
      const data = {
        configured: adminReady(),
        adminConfigured: adminReady(),
        locations: [],
        events: [],
        deleted: [],
        reports: [],
      }
      if (ready()) {
        const [loc, ev, re, reps] = await Promise.all(['location', 'event', 'deleted', 'reports'].map(list))
        Object.assign(data, {
          locations: loc,
          events: ev,
          deleted: re,
          reports: reps
            .filter((r) => ['approved', 'resolved'].includes(r.status))
            .map(({ email: _, ...r }) => r),
        })
      }
      return send(res, 200, data)
    }
    if (!ready()) fail(503, 'Publicarea nu este configurată. Conținutul nu a fost trimis.')
    if (action === 'image' && req.method === 'GET') {
      const id = slug(target.searchParams.get('id')),
        m = await get('media', id)
      if (!m) fail(404, 'Fotografie indisponibilă.')
      res.setHeader('Content-Type', 'image/webp')
      res.setHeader('Cache-Control', 'no-store')
      return res.end(Buffer.from(m.data, 'base64'))
    }
    if (action === 'report' && req.method === 'POST') {
      if (!adminReady()) fail(503, 'Primirea contribuțiilor necesită și un cont de moderare configurat.')
      await limit(req, 'report', 5, 3600)
      if (body.consent !== true || !kinds.includes(body.kind))
        fail(400, 'Categoria și acordul sunt obligatorii.')
      const entry = {
        id: randomUUID(),
        title: text(body.title, 5, 120),
        description: text(body.description, 15, 2000),
        location: text(body.location, 3, 180),
        kind: body.kind,
        status: 'pending',
        created: new Date().toISOString(),
        photo: '',
      }
      if (body.photo) {
        // A submitted image is private from its very first write.
        entry.photo = await photo(body.photo, true)
      }
      await write('reports', entry.id, entry)
      return send(res, 201, { id: entry.id, status: 'pending' })
    }
    if (action === 'login' && req.method === 'POST') {
      if (!adminReady()) fail(503, 'Contul administrativ nu este configurat.')
      await limit(req, 'login', 8, 900)
      const [salt, stored] = process.env.ATLAS_ADMIN_HASH.split(':')
      const pw = text(body.password, 1, 256),
        candidate = await scrypt(pw, salt, 64)
      if (
        !timingSafeEqual(Buffer.from(stored, 'hex'), candidate) ||
        body.username !== process.env.ATLAS_ADMIN_USER
      )
        fail(401, 'Date de autentificare incorecte.')
      const id = randomBytes(32).toString('hex'),
        csrf = randomBytes(24).toString('hex')
      await cmd(
        'SET',
        prefix + 'session:' + hash(id),
        JSON.stringify({ role: 'administrator', csrf, user: process.env.ATLAS_ADMIN_USER }),
        'EX',
        ttl,
      )
      res.setHeader(
        'Set-Cookie',
        `__Host-atlas_admin=${id}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${ttl}`,
      )
      return send(res, 200, { authenticated: true, csrf })
    }
    const session = await auth(req)
    if (action === 'session' && req.method === 'GET')
      return send(res, 200, { authenticated: true, csrf: session.csrf, user: session.user })
    if (action === 'logout' && req.method === 'POST') {
      await cmd('DEL', prefix + 'session:' + hash(sessionId(req)))
      res.setHeader('Set-Cookie', '__Host-atlas_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0')
      return send(res, 200, { ok: true })
    }
    if (action === 'moderation' && req.method === 'GET') {
      const reports = await list('reports')
      return send(
        res,
        200,
        reports.map((r) => ({ ...r, photo: r.photo?.replace('action=image', 'action=review-image') })),
      )
    }
    if (action === 'review-image' && req.method === 'GET') {
      const id = slug(target.searchParams.get('id')),
        m = (await get('private-media', id)) || (await get('media', id))
      if (!m) fail(404, 'Imagine indisponibilă.')
      res.setHeader('Content-Type', 'image/webp')
      return res.end(Buffer.from(m.data, 'base64'))
    }
    if (action === 'moderate' && req.method === 'POST') {
      const id = slug(body.id),
        r = await get('reports', id)
      if (!r) fail(404, 'Sesizare inexistentă.')
      if (!['approved', 'rejected', 'resolved'].includes(body.status)) fail(400, 'Stare invalidă.')
      if (body.title !== undefined) r.title = text(body.title, 5, 120)
      if (body.description !== undefined) r.description = text(body.description, 15, 2000)
      if (r.photo) {
        const key = r.photo.split('id=')[1],
          dest = body.status === 'rejected' ? 'private-media' : 'media',
          old = dest === 'media' ? 'private-media' : 'media',
          im = await get(old, key)
        if (im) {
          await write(dest, key, im)
          await cmd('HDEL', prefix + old, key)
        }
      }
      await write('reports', id, { ...r, status: body.status, reviewed: new Date().toISOString() })
      return send(res, 200, { ok: true })
    }
    if (action === 'upload' && req.method === 'POST') return send(res, 201, { url: await photo(body.photo) })
    if (!sections.includes(body.kind) || !['save', 'delete'].includes(action) || req.method !== 'POST')
      fail(404, 'Operațiune necunoscută.')
    const kind = body.kind,
      id = slug(body.id)
    if (action === 'delete') {
      await write('deleted', id, id)
      await cmd('HDEL', prefix + kind, id)
      return send(res, 200, { ok: true })
    }
    const p = body.record || {}
    let out
    if (kind === 'location') {
      const lat = Number(p.lat),
        lon = Number(p.lon)
      const X = ((lon + 180) / 360) * 16777216 - 9232 * 1024,
        Y = ((1 - Math.asinh(Math.tan((lat * Math.PI) / 180)) / Math.PI) / 2) * 16777216 - 5834 * 1024
      if (
        !Number.isFinite(X) ||
        !Number.isFinite(Y) ||
        X < 0 ||
        X > 5120 ||
        Y < 0 ||
        Y > 5120 ||
        !categories.includes(p.category)
      )
        fail(400, 'Categoria sau coordonatele nu aparțin hărții Devei.')
      out = {
        id,
        name: text(p.name, 2, 100),
        category: p.category,
        lat,
        lon,
        label: 'below',
        intro: text(p.intro, 8, 350),
        story: text(p.story, 8, 5000),
        location: text(p.location, 2, 150),
        address: text(p.address, 2, 220),
        tip: text(p.tip || 'Verifică detaliile direct la sursa indicată.', 2, 1500),
        image: imageRef(p.image),
        cartogram: !!p.cartogram,
        businessType: text(p.businessType || '', 0, 50),
        hours: text(p.hours || '', 0, 500),
        phone: text(p.phone || '', 0, 40),
        website: url(p.website, true),
        checked: new Date().toISOString().slice(0, 10),
        sources: [{ label: 'Sursa informației', url: url(p.source) }],
        photoCredit: text(p.photoCredit || '', 0, 300),
        photoSource: url(p.photoSource, true),
        representative: !!p.representative,
      }
      if (out.phone && !/^[\d +()./-]+$/.test(out.phone)) fail(400, 'Telefon invalid.')
    } else {
      const start = new Date(text(p.start, 10, 42))
      if (!Number.isFinite(start.getTime())) fail(400, 'Data evenimentului este invalidă.')
      const end = p.end ? new Date(p.end) : null
      if (end && (!Number.isFinite(end.getTime()) || end < start))
        fail(400, 'Intervalul evenimentului este invalid.')
      out = {
        id,
        title: text(p.title, 3, 140),
        start: start.toISOString(),
        end: end?.toISOString(),
        venue: text(p.venue, 3, 180),
        description: text(p.description, 10, 3000),
        type: text(p.type, 2, 50),
        source: url(p.source),
        updated: new Date().toISOString().slice(0, 10),
      }
    }
    await write(kind, id, out)
    await cmd('HDEL', prefix + 'deleted', id)
    return send(res, 200, { ok: true, id })
  } catch (e) {
    const c = Number.isInteger(e.code) ? e.code : e instanceof SyntaxError ? 400 : 503
    return send(res, c, {
      error:
        c === 503 && !e.code
          ? 'Serviciul nu răspunde. Nu considerăm operațiunea finalizată.'
          : e.code
            ? e.message
            : 'Solicitare invalidă.',
    })
  }
}
export const config = { api: { bodyParser: { sizeLimit: '3mb' } } }
